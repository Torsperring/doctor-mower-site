async function loadContent(){
  const res = await fetch('content/site.json?ts=' + Date.now(), {cache:'no-store'});
  if(!res.ok) throw new Error('Could not load site content');
  return res.json();
}
function text(id, value){const el=document.getElementById(id); if(el) el.textContent=value ?? '';}
function html(id, value){const el=document.getElementById(id); if(el) el.innerHTML=value ?? '';}
function setupMenu(){const btn=document.getElementById('menu');const nav=document.getElementById('nav');if(btn&&nav)btn.onclick=()=>nav.classList.toggle('open');}
function applyCommon(data){
  const b=data.business;
  document.querySelectorAll('[data-phone-display]').forEach(e=>e.textContent=b.phone_display);
  document.querySelectorAll('[data-phone-link]').forEach(e=>e.setAttribute('href','tel:'+b.phone_link));
  document.querySelectorAll('[data-email]').forEach(e=>{e.textContent=b.email;e.setAttribute('href','mailto:'+b.email)});
  document.querySelectorAll('[data-service-area]').forEach(e=>e.textContent=b.service_area);
}
async function initHome(){
  const data=await loadContent(); applyCommon(data); const h=data.home;
  text('headlineTop',h.headline_top); text('headlineGold',h.headline_gold); text('subheading',h.subheading); text('locationText',h.location_text);
  text('bookButton',h.book_button); text('bookSmall',h.book_small); text('equipmentHeading',h.equipment_heading);
  document.getElementById('equipmentGrid').innerHTML=h.equipment.map(x=>`<div>${x}</div>`).join('');
  document.getElementById('features').innerHTML=h.features.map((x,i)=>`<div class="card"><h3>${x.title}</h3><p>${x.text}</p></div>`).join('');
  text('aboutHeading',h.about_heading); text('about1',h.about_paragraph_1); text('about2',h.about_paragraph_2); setupMenu();
}
async function initBooking(){
  const data=await loadContent(); applyCommon(data); const b=data.booking;
  text('bookingHeading',b.heading); text('bookingIntro',b.intro); text('howHeading',b.how_heading); text('howText',b.how_text);
  const m=document.getElementById('machineType'); b.machine_types.forEach(x=>{const o=document.createElement('option');o.textContent=x;o.value=x;m.appendChild(o)});
  document.getElementById('serviceTypes').innerHTML=b.service_types.map((x,i)=>`<label><input type="radio" name="service" value="${x}" ${i===0?'required':''}> ${x}</label>`).join('');
  setupMenu(); setupForm(data.business.email);
}
function setupForm(email){
  const f=document.getElementById('bookingForm'),s=document.getElementById('status');
  f.action='https://formsubmit.co/ajax/'+email;
  f.addEventListener('submit',async e=>{
    e.preventDefault(); if(!f.reportValidity()) return;
    const btn=f.querySelector('.submit'); btn.disabled=true; btn.textContent='Sending...';
    s.className='status show'; s.textContent='Sending your service request...';
    try{const r=await fetch(f.action,{method:'POST',body:new FormData(f),headers:{Accept:'application/json'}});if(!r.ok)throw new Error();f.reset();s.className='status show ok';s.textContent='Thanks! Your service request has been sent to Doctor Mower.'}
    catch(e){s.className='status show bad';s.textContent='Sorry, your request could not be sent. Please call or text Doctor Mower.'}
    finally{btn.disabled=false;btn.textContent='Send Service Request'}
  });
}