DOCTOR MOWER - EDITABLE WEBSITE

What is editable:
- Business phone, email and service area
- Homepage headline and text
- Equipment list
- Feature cards
- About section
- Booking page text
- Machine type options
- Service/repair options

How editing works:
1. The website content lives in content/site.json.
2. The /admin page is prepared for Decap CMS.
3. To activate /admin, put this folder in a GitHub repository named doctor-mower-site.
4. GitHub username has been set to Torsperring in admin/config.yml.
5. Connect that GitHub repository to Vercel.
6. Configure GitHub authentication for Decap CMS.
7. Then visit https://YOUR-DOMAIN/admin/ to edit the website.

Even before /admin is activated, content/site.json is deliberately simple and can be edited directly in GitHub's web editor.

IMPORTANT:
Decap CMS's GitHub backend needs authentication setup before /admin can save changes. The website itself works without that authentication.
